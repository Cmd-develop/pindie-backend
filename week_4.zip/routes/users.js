const usersRouter = require('express').Router();

const { findAllUsers, createUser, findUserById, updateUser, deleteUser } = require('../middlewares/users');
const { sendUserCreated, sendUserById, sendUserUpdated, sendUserDeleted, sendAllUsers } = require('../controllers/users');

usersRouter.post(
    "/users",
    findAllUsers,
    createUser,
    sendUserCreated
);

usersRouter.get("/users/:id", findUserById, sendUserById);

usersRouter.get("/users", findUserById, sendAllUsers);

usersRouter.put("/users/:id", updateUser, sendUserUpdated);

usersRouter.delete("/users/:id", deleteUser, sendUserDeleted);

module.exports = usersRouter;
